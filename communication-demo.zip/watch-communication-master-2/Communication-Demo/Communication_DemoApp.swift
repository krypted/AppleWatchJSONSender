//
//  Communication_DemoApp.swift
//  Communication-Demo
//
//

import SwiftUI

@main
struct Communication_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
