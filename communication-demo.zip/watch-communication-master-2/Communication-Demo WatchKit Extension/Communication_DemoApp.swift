//
//  Communication_DemoApp.swift
//  Communication-Demo WatchKit Extension
//
//

import SwiftUI

@main
struct Communication_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
            }
        }
    }
}
