//
//  Communication_DemoApp.swift
//  Communication-Demo WatchKit Extension
//
//  Created by Charles Edge on 07/04/22.
//

import SwiftUI

@main
struct Communication_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
            }
        }
    }
}
